document.getElementById("contactform").onsubmit = function () {
  alert("Your inquiry has been submitted. ");
  return false; 
};

document.getElementsByTagName("tr")[1].onclick = function () {
  alert("CupCake Sold Out");
};

